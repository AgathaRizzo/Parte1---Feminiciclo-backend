package br.edu.ifsp.feminicicloapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeminicicloapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
