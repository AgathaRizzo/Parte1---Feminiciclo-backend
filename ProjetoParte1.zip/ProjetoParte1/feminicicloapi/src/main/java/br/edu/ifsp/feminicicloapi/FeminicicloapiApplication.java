package br.edu.ifsp.feminicicloapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import br.edu.ifsp.feminicicloapi.repository.FeedbackRepository;

@CrossOrigin
@RestController
@SpringBootApplication
public class FeminicicloapiApplication {

	public static void main(String[] args) {
		FeedbackRepository.init();
		SpringApplication.run(FeminicicloapiApplication.class, args);
	}

}
