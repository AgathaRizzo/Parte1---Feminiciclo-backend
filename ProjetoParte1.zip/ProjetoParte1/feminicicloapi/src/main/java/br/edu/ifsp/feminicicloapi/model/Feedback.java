package br.edu.ifsp.feminicicloapi.model;

public class Feedback {

    private int id;
    private String descricao;
    private static int idCounter = 0;


    public Feedback(){
        this.id = ++Feedback.idCounter;
    }


    public Feedback(int id, String descricao) {
        this.id = id;
        this.descricao = descricao;
        this.id = ++Feedback.idCounter;
    }


    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public String getDescricao() {
        return descricao;
    }


    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
}
